1. audio5.py encodes a hardcoded text in test.wav and makes it song_embedded.wav

2. audio6.py decodes a hardcoded text in song_embedded.wav and prints it on screen.

3. audio2.py plays the audio when we run the program.
