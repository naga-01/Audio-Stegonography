
import pygame
pygame.mixer.init()
pygame.mixer.music.load("/home/user/Desktop/audio/song_embedded.wav")
pygame.mixer.music.play()
while pygame.mixer.music.get_busy() == True:
    continue
